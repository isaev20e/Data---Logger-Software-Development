#include <stdio.h>

int main(){
  printf("this\n");
  return 0;
}
